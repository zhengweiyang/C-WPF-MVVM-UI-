﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.Prism.Mvvm;

namespace myTest.Model
{
    public class A : BindableBase
    {
        private string b;
        public string B
        {
            get
            {
                return this.b;
            }
            set
            {
                SetProperty(ref this.b, value);
            }
        }
        //public string B { get; set; } //若只用这句不行！
    }
}
