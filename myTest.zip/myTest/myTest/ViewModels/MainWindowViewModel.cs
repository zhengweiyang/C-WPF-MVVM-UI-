﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Threading.Tasks;
using myTest.Model;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Mvvm;

namespace myTest.ViewModels
{
    public class MainWindowViewModel : BindableBase
    {
        private A a;
        public A A
        {
            get { return this.a; }
            set
            {
                SetProperty(ref this.a, value);
                OnPropertyChanged(() => this.a.B);
            }
        }
        public ICommand SubmitCommand { get; private set; }
   
        public MainWindowViewModel()
        {
            this.A = new A();
            this.SubmitCommand = new DelegateCommand(this.OnSubmit);
        }

        private void OnSubmit()
        {
            Console.WriteLine("abc");
            this.A.B = DateTime.Now.ToLongTimeString();
            Console.WriteLine(this.A.B);
        }
    }
}
